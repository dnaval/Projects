<?php
class Config_ORCL
{

    public function configPDO_ORCL() 
    {

        $hote = '172.20.242.55';
        $port = '1521'; // port par défaut
        $service = 'ICT';
        $utilisateur = 'ICTPRDI';
        $motdepasse = 'ictprdi';

        $lien_base =
        "oci:dbname=(DESCRIPTION =
        (ADDRESS_LIST =
                (ADDRESS =
                        (PROTOCOL = TCP)
                        (Host = ".$hote .")
                        (Port = ".$port."))
        )
        (CONNECT_DATA =
                (SID = ".$service.")
        )
        )";

		//$connexion = new PDO($lien_base, $utilisateur, $motdepasse);
        try
        {
                // connexion à la base Oracle et création de l'objet
                $connexion = new PDO($lien_base, $utilisateur, $motdepasse);
        }
        catch (PDOException $erreur)
        {
                echo $erreur->getMessage();
        } 
          return $connexion;
    }

}
