<?php
 
 /**
 * Description of Mysql Export
 *
 * @author daniel naval
 */
 
 //Temp fichier
  $fichier = "./temp/Book.xlsx";

//Package PHP&Excel
require_once './PHPExcel/Classes/PHPExcel.php';

//Class content all methode for this application
require_once './ExcelReport.php';

//Connexion to Reportmgr
require './config/connect.php'; 

  //Object of the class
$dan = new ExcelReport();
$objPHPExcel = $dan->Load_File($fichier);

//Execute query
$req = "SELECT * FROM `internet_shop`";
$result = mysql_query($req);

//Make a report from Oracle
$dan->MysqlExport($objPHPExcel,$result,$fichier);

//Copy the file and make a backup
$file = $dan->Copy_File($fichier,'Mysql');

//Display the data export
$dan->Mysql_Display($result);

//Copy the file and make a backup
$dan->Backup_File($file,'Mysql');

?>
